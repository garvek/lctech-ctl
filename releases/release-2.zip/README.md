# lctech-ctl
LC Tech USB Control app for LCUS-1 relay module

you can get the product on amazon:
https://www.amazon.fr/gp/product/B07DJ549LX/

official documentation:
http://www.lctech-inc.com/cpzx/2/jdqmk/2019/0111/62.html
